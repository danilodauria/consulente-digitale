#!/bin/sh
cd "$(dirname "$0")" && CD_SHARE_DIR="$PWD/app" exec python3 app/server/cd_server.py --apri
