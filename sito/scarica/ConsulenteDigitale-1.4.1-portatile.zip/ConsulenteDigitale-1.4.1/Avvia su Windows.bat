@echo off
start "" wscript.exe "%~dp0avvia.vbs"
